<?php
/**
 * Plugin Name: Login Auth
 * Plugin URI: https://hritwickb.me/project/login auth
 * Description: Login Auth Using time-Based One-Time Passwords, Universal 2nd Factor (FIDO U2F), Email and Backup Verification Codes.
 * Author: Prayangshu Biswas Hritwick
 * Version: 1.0
 * Author URI: https://hritwickb.me
 * Network: True
 * Text Domain: https://hritwickb.me
 */

/**
 * Shortcut constant to the path of this file.
 */
define( 'TWO_FACTOR_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Include the base class here, so that other plugins can also extend it.
 */
require_once( TWO_FACTOR_DIR . 'providers/class.two-factor-provider.php' );

/**
 * Include the core that handles the common bits.
 */
require_once( TWO_FACTOR_DIR . 'class-two-factor-core.php' );

/**
 * A compatability layer for some of the most-used plugins out there.
 */
require_once( TWO_FACTOR_DIR . 'class-two-factor-compat.php' );

$two_factor_compat = new Two_Factor_Compat();

Two_Factor_Core::add_hooks( $two_factor_compat );
